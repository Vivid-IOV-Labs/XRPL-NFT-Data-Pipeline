
XRPL_SERVER_1 = "https://xrplcluster.com"
XRPL_SERVER_2 = "https://s1.ripple.com:51234"
XRPL_SERVER_3 = "https://s2.ripple.com:51234"