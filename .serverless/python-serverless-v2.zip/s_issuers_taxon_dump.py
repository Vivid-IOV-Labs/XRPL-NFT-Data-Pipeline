import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='peerkatserverless',
    application_name='python-serverless-xls20',
    app_uid='BJkYrgS1bkxyfDdlM1',
    org_uid='a48ec88a-283c-4198-a203-db9ca06ecee6',
    deployment_uid='e2c8afc6-257f-477f-93fd-f629c3cc042c',
    service_name='python-serverless-v2',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'issuers-taxon-dump-dev', 'timeout': 900}
try:
    user_handler = serverless_sdk.get_user_handler('handlers.issuers_taxon_dumps')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
