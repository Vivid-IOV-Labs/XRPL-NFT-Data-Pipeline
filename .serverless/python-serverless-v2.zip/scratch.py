# import os
# import datetime
#
#
# def get_dumped_offers(issuer, taxon):
#     try:
#         now = datetime.datetime.now()
#         tokens = os.listdir(f"data/offers/{issuer}/taxon-{taxon}/{now.strftime('%Y-%m-%d-%H')}")
#         return [token.replace(".json", "") for token in tokens]
#     except FileNotFoundError:
#         return []
#
# async def dump_token_offers(issuer, taxon, token_id):
#     for server in Config.XRPL_SERVERS:
#         try:
#             offers = await get_token_offer(token_id, server)
#             average = sum(offers)/len(offers) if offers else 0
#             return average
#             # data = {"offers": offers}
#             # now = datetime.datetime.now()
#             # LocalFileWriter().write_json(data, f"data/offers/{issuer}/taxon-{taxon}/{now.strftime('%Y-%m-%d-%H')}", f"{token_id}.json")
#             # break
#         except httpx.RequestError as e:
#             print(f"Failed Using {server}: Retrying ...", str(e))
#             continue
#     print(f"Could not get offers from any server for issuer {issuer}, taxon {taxon}, and token {token_id}")
#     return 0
#
# async def taxon_offers(taxon, issuer, tokens):
#     # print(f"Executing Taxon Offers for {taxon}")
#     # already_processed = get_dumped_offers(issuer, taxon)
#     # print(f"Already Processed {len(already_processed)}")
#     # to_process = list(set([token["NFTokenID"] for token in tokens]).difference(set(already_processed)))
#     # print(len(to_process))
#     now = datetime.datetime.now()
#     offers = []
#     for chunk in chunks(tokens, 1000):
#         averages = await asyncio.gather(*[dump_token_offers(issuer, taxon, token["NFTokenID"]) for token in chunk])
#         offers.extend([average for average in averages if average != 0])
#         time.sleep(20)
#     data = {"taxon": taxon, "issuer": issuer, "average_price": sum(offers)/len(offers) if offers else 0}
#     LocalFileWriter().write_json(data, f"data/pricing/{now.strftime('%Y-%m-%d-%H')}", f"{issuer}-{taxon}.json")
#     # return {"taxon": taxon, "issuer": issuer, "average_price": sum(offers)/len(offers) if offers else 0}
